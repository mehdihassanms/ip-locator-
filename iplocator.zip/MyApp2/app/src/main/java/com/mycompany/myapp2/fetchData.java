package com.mycompany.myapp2;
import android.os.*;
import java.net.URL;
import java.net.*;
import java.io.*;
import android.graphics.*;
import org.json.*;
import com.google.gson.*;
import android.renderscript.*;
import java.util.*;
import com.google.gson.reflect.*;
import com.google.gson.internal.*;
import android.util.*;
import com.android.volley.toolbox.*;
import com.android.volley.*;
import com.github.kevinsawicki.http.*;

public abstract class fetchData extends AsyncTask<Void,Void,String>
{
	String Data;
	String DataParsed="";
	String singleParsed="";
	JsonValues jsonValues;
	Gson gson;
	HashMap <String,Object> JO =new HashMap<>();
	@Override
	protected String doInBackground(Void... a)
	{
		try
		{
		URL url = new URL(MainActivity.apiUrl);
		return HttpRequest.get(url).body();
	
		}catch (Exception e)
		{}
		
		return null;
	}

	@Override
	protected void onPostExecute(String result)
	{
		onComplete(result);
		super.onPostExecute(result);
	}
	public abstract void onComplete(String result)
	public void Run(){
		this.execute();
	}
	
	
}
