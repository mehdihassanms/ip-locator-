package com.mycompany.myapp2;

import android.app.*;
import android.content.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import java.util.*;
import com.google.gson.*;
import com.startapp.android.publish.adsCommon.*;

public class MainActivity extends Activity 
{
	
	Button b;
	public static String apiUrl;
	private static Context context;
	private String developerAuthKey;
	private String TargetIP;
	public static HashMap <String,Object> TargetData =new HashMap<>();
	
	private Data d;
	
	private String dialogText;

	private EditText ipbox;
	
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		
		StartAppSDK.init(this, "207201049", true);
		
		context = getBaseContext();
		ipbox= (EditText)findViewById(R.id.iptextbox);
		
		b = (Button) findViewById(R.id.mainButton);
		
		developerAuthKey="23e0d9d2-7e8b-4bbb-9095-0d2418dab779";
		TargetIP="118.107.141.94";
		
		b.setOnClickListener( new View.OnClickListener(){

				

				@Override
				public void onClick(View p1)
				{
					TargetIP=ipbox.getText().toString();
					apiUrl="https://ipfind.co/?ip="+TargetIP+"&auth="+developerAuthKey;
					
					
					new fetchData(){

						@Override
						public void onComplete(String result)
						{
							d = new Gson().fromJson(result,Data.class);
							setData(d);
							openDialog();
						}
					}.Run();
					
					
					
				}
				
				public void openDialog(){
					AlertDialog dialog = new AlertDialog.Builder(MainActivity.this).create();
					dialog.setTitle(TargetIP);
					dialog.setMessage(dialogText);
					dialog.setButton(AlertDialog.BUTTON_NEGATIVE, "OK",
						new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog, int which) {
								dialog.dismiss();
							}
						});
					dialog.show();
					}
				
				public void setData(Data _d){
					
					
					dialogText="Country:	   "+_d.getCountry()+"\n";
					dialogText=dialogText+"Country Code:	   "+ _d.getCountryCode()+"\n";
				 	dialogText=dialogText+"Continent:	   "+ _d.getContinent()+"\n";
					dialogText=dialogText+"Continent Code:	   "+_d.getContinentCode()+"\n";
					dialogText=dialogText+"City:	   "+ _d.getCity()+"\n";
					dialogText=dialogText+ "County:	   "+ (String) _d.getCounty()+"\n";
					dialogText=dialogText+ "Region:	   "+_d.getRegion()+"\n";
					dialogText=dialogText+ "Region Code:	   "+_d.getRegionCode()+"\n";
					dialogText=dialogText+"Timezone:	   "+ _d.getTimezone()+"\n";
					dialogText=dialogText+"Owner:	   "+ (String) _d.getOwner()+"\n";
					dialogText=dialogText+ "Longitude:	   "+_d.getLongitude().toString()+"\n";
					dialogText=dialogText+ "Latitude:	   "+_d.getLatitude().toString()+"\n";
					dialogText=dialogText+ "Currency:	   "+_d.getCurrency()+"\n";
					dialogText=dialogText+"Languages:	   "+ _d.getLanguages().toString()+"\n";
				}
			
		});
	}
		
	

			public static void message(String toString)
			{
				Toast.makeText(context,toString,Toast.LENGTH_SHORT).show();
			}
}
