package com.mycompany.myapp2;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Data {

	@SerializedName("ip_address")
	@Expose
	private String ipAddress;
	@SerializedName("country")
	@Expose
	private String country;
	@SerializedName("country_code")
	@Expose
	private String countryCode;
	@SerializedName("continent")
	@Expose
	private String continent;
	@SerializedName("continent_code")
	@Expose
	private String continentCode;
	@SerializedName("city")
	@Expose
	private String city;
	@SerializedName("county")
	@Expose
	private Object county;
	@SerializedName("region")
	@Expose
	private String region;
	@SerializedName("region_code")
	@Expose
	private String regionCode;
	@SerializedName("timezone")
	@Expose
	private String timezone;
	@SerializedName("owner")
	@Expose
	private Object owner;
	@SerializedName("longitude")
	@Expose
	private Double longitude;
	@SerializedName("latitude")
	@Expose
	private Double latitude;
	@SerializedName("currency")
	@Expose
	private String currency;
	@SerializedName("languages")
	@Expose
	private List<String> languages = null;

	public String getIpAddress() {
		return ipAddress;
	}

	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public String getContinent() {
		return continent;
	}

	public void setContinent(String continent) {
		this.continent = continent;
	}

	public String getContinentCode() {
		return continentCode;
	}

	public void setContinentCode(String continentCode) {
		this.continentCode = continentCode;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public Object getCounty() {
		return county;
	}

	public void setCounty(Object county) {
		this.county = county;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getRegionCode() {
		return regionCode;
	}

	public void setRegionCode(String regionCode) {
		this.regionCode = regionCode;
	}

	public String getTimezone() {
		return timezone;
	}

	public void setTimezone(String timezone) {
		this.timezone = timezone;
	}

	public Object getOwner() {
		return owner;
	}

	public void setOwner(Object owner) {
		this.owner = owner;
	}

	public Double getLongitude() {
		return longitude;
	}

	public void setLongitude(Double longitude) {
		this.longitude = longitude;
	}

	public Double getLatitude() {
		return latitude;
	}

	public void setLatitude(Double latitude) {
		this.latitude = latitude;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public List<String> getLanguages() {
		return languages;
	}

	public void setLanguages(List<String> languages) {
		this.languages = languages;
	}

	}
	
