package com.mycompany.myapp2;

public class JsonValues
{
	private String ip_address
			,country,
	country_code,
	continent,
	continent_code,
	city,
	county,
	region,
	region_code,
	timezone,
	owner,
	longitude,
	latitude,
	currency,
	languages;
	
	
	public void JsonValues(String _ip_address,String _country,String _countryCode, String _continent,String _continentCode, String _city,String _county, String _region,String _region_code, String _timezone,String _owner,String _longitude,String _latitude,String _currency,String _languages){
		ip_address =_ip_address;
		country = _country;
		country_code = _countryCode;
		continent = _continent;
		continent_code= _continentCode;
		city = _city;
		county = _county;
		region = _region;
		region_code =_region_code;
		timezone = _timezone;
		owner = _owner;
		longitude = _longitude;
		latitude = _latitude;
		currency =_currency;
		languages=_languages;
	}
	
	
}
